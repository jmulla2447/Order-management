package org.mulla.in.Email_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
